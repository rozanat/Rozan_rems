A small Project created by : 
-Salina Pradhan 
-Rojan Adhikari 

We have developed a cutting-edge project named the "Real Estate Management System." 
This innovative system is poised to revolutionize the real estate industry by streamlining property management processes and enhancing user experience.
The Real Estate Management System is designed to empower real estate professionals, property owners, and tenants alike, providing them with a user-friendly interface to navigate the complexities of property transactions effortlessly
              